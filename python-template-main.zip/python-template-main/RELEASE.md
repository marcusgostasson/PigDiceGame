Release history
========================

Decide on a way how to handled your relaeases and version numbers. Document it here.

For example like this...



v2.0.0 (2022-02-05)
------------------------

* Moved to a new location.



v1.1.0 (2021-02-12)
------------------------

* Enabling generating documentation from comments using pdoc and pydoc.
* Enabling UML documentation using pyreverse.



v1.0.0 (2021-02-12)
------------------------

* First release, extracted from course material and further developed.
